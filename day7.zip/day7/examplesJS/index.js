function myFun()
{
    var myval = document.getElementById("para1").innerHTML;
    alert(myval);
    document.getElementById("para1").innerHTML="hey u go ahead";
}