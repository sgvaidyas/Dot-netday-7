function funct1()
{
    var x;
    var a="apple";
    var b=77;
    var c="223";
    var ob = {"name":"Shilpa","State":"Karnataka"};
    var ob2=[33,44,55];

    document.write("x = " + x + "=" + typeof(x) +"<br>");
    document.write("a = " + a  + "=" +  typeof(a) +"<br>");
    document.write("b = " + b  + "=" +  typeof(b) +"<br>");
    document.write("c = " + c  + "=" + typeof(c) +"<br>");
    document.write("ob = " + ob  + "=" + typeof(ob) +"<br>");
    document.write("ob2 = " +ob2 + "=" +  typeof(ob2) +"<br>");
    
    

}